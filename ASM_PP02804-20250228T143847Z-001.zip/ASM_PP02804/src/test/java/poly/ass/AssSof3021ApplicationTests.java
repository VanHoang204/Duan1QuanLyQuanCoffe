package poly.ass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssSof3021ApplicationTests {

	@Test
	void contextLoads() {
	}

}
